package tragaperras;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Timer;
public class Interfaz extends javax.swing.JFrame implements Runnable {
Thread hilo1;
Thread hilo2;
Thread hilo3;
    public Interfaz() {
        initComponents();
        setLocationRelativeTo(null);
    }
    int c1=0,c2=0,c3=0;
    static int contador=0, contador2=0, contador3=0;
    Timer tiempo1 = new Timer (100, new ActionListener ()
{
    public void actionPerformed(ActionEvent e)
    {
          ImageIcon img;
          contador=(int) (Math.random()*6);
                switch (contador) { //Recorre cada imagen y la muestra en el Label
                    case 0:
                      contador = 1;
                      img = new ImageIcon("1.png");
                      jLabel5.setIcon(img);
                        break;
                    case 1:
                        contador = 2;
                        img = new ImageIcon("2.png");
                        jLabel5.setIcon(img);
                        break;
                    case 2:
                        contador = 3;
                        img = new ImageIcon("3.png");
                        jLabel5.setIcon(img);
                        break;
                    case 3:
                        contador = 4;
                        img = new ImageIcon("4.png");
                        jLabel5.setIcon(img);
                        break;
                    case 4:
                        contador = 5;
                        img = new ImageIcon("5.png");
                        jLabel5.setIcon(img);
                        break;
                    case 5:
                        contador = 0;
                        img = new ImageIcon("6.png");
                        jLabel5.setIcon(img);
                        break;
                }
    }
});
     Timer tiempo2 = new Timer (100, new ActionListener ()
{
    public void actionPerformed(ActionEvent e)
    {
          ImageIcon img;
          contador2=(int) (Math.random()*6);
                switch (contador2) { //Recorre cada imagen y la muestra en el Label
                    case 0:
                      contador2 = 1;
                      img = new ImageIcon("1.png");
                      jLabel6.setIcon(img);
                        break;
                    case 1:
                        contador2 = 2;
                        img = new ImageIcon("2.png");
                        jLabel6.setIcon(img);
                        break;
                    case 2:
                        contador2 = 3;
                        img = new ImageIcon("3.png");
                        jLabel6.setIcon(img);
                        break;
                    case 3:
                        contador2 = 4;
                        img = new ImageIcon("4.png");
                        jLabel6.setIcon(img);
                        break;
                    case 4:
                        contador2 = 5;
                        img = new ImageIcon("5.png");
                        jLabel6.setIcon(img);
                        break;
                    case 5:
                        contador2 = 0;
                        img = new ImageIcon("6.png");
                        jLabel6.setIcon(img);
                        break;
                }
    }
});
     Timer tiempo3 = new Timer (100, new ActionListener ()
{
    public void actionPerformed(ActionEvent e)
    {
          ImageIcon img;
          contador3=(int) (Math.random()*6);
                switch (contador3) { //Recorre cada imagen y la muestra en el Label
                    case 0:
                      contador3 = 1;
                      img = new ImageIcon("1.png");
                      jLabel7.setIcon(img);
                        break;
                    case 1:
                        contador3 = 2;
                        img = new ImageIcon("2.png");
                        jLabel7.setIcon(img);
                        break;
                    case 2:
                        contador3 = 3;
                        img = new ImageIcon("3.png");
                        jLabel7.setIcon(img);
                        break;
                    case 3:
                        contador3 = 4;
                        img = new ImageIcon("4.png");
                        jLabel7.setIcon(img);
                        break;
                    case 4:
                        contador3 = 5;
                        img = new ImageIcon("5.png");
                        jLabel7.setIcon(img);
                        break;
                    case 5:
                        contador3 = 0;
                        img = new ImageIcon("6.png");
                        jLabel7.setIcon(img);
                        break;
                }
    }
});
 
    public void run(){
      for (int i=0;i<6;i++){
          try {
         Thread.sleep( 600 );
     } catch (InterruptedException ex) {
         Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
     }
          
    // System.out.println(i+" "+Thread.currentThread().getName());
      }
       // System.out.println(Thread.currentThread().isAlive());
        if(Thread.currentThread().isAlive() == true)
        {
            tiempo1.stop();
            tiempo2.stop();
            tiempo3.stop();
            
        }
        if(contador==contador2 && contador==contador3 && contador2==contador3)
            JOptionPane.showMessageDialog(null, "¡¡JACKPOT!!");
        System.out.println("Aqui termina la ejecución del hilo "+Thread.currentThread().getName()); 
     
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Label3 = new javax.swing.JLabel();
        Label2 = new javax.swing.JLabel();
        Label = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();

        jButton1.setText("Iniciar Juego");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("jButton2");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 110, 160, 150));
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 110, 160, 150));
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 110, 160, 150));

        jButton3.setText("iniciar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 360, -1, -1));

        jTextField1.setText("tragaperras");
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 50, -1, -1));

        jButton4.setText("volver");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 410));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        tiempo1.start();
        tiempo2.start();
        tiempo3.start();
        hilo1= new Thread(this);
        hilo2= new Thread(this);
        hilo3= new Thread(this);
        hilo1.start();
        hilo2.start();
        hilo3.start();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        casino_1 newframe = new casino_1 ();
        newframe.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Label;
    private javax.swing.JLabel Label2;
    private javax.swing.JLabel Label3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
